/*c4.1.c file: practica 3 de la clase SOTR
 * Compute matrix sum by threads
 *
 *
 * Este codigo se escribe sobre el ejemplo #0
**************************/

#include "includes.h"

/*
*********************************************************************************************************
*                                               CONSTANTS
*********************************************************************************************************
*/
#define     N                           4		//Tamaño de la matriz
#define     TASK_STK_SIZE		512		//number of task stack (#of words)
#define     N_TASKS		        N		//numero de tasks identicos

int A[N][N], sum[N];					//Matriz de NxN
int total = 0, count = 0;						//suma

/*
*********************************************************************************************************
*                                               VARIABLES
*********************************************************************************************************
*/
OS_STK  TaskStk[N_TASKS][TASK_STK_SIZE];			//Task Stack
OS_STK  TaskStartSTK[TASK_STK_SIZE];
char    TaskData[N_TASKS];                      /* Parameters to pass to each task */
OS_EVENT    *SemM;                              //Semaforo para modificar A y sum
OS_EVENT    *SemTotal;

/*
*********************************************************************************************************
*                                           FUNCTION PROTOTYPES
*********************************************************************************************************
*/
void Task(void *arg);                                   // Thread function
void TaskStart(void *pdata);
static  void  TaskStartCreateTasks (void);
int kbhit(); 
/*
*********************************************************************************************************
*                                                MAIN
*********************************************************************************************************
*/
int main(void)
{
    // Display a banner.
#ifdef __WIN32__
    printf("##### uCOS-II V%4.2f Port V%4.2f for WIN32 #####\n", ((FP32)OSVersion())/100, ((FP32)OSPortVersion())/100);
#endif
#ifdef __LINUX__
    printf("##### uCOS-II V%4.2f Port V%4.2f for LINUX #####\n", ((FP32)OSVersion())/100, ((FP32)OSPortVersion())/100);
#endif

    OSInit();                          // Initialize uCOS-II.

    SemM = OSSemCreate(1);              //crear Semaforo inicializado a 1
    SemTotal = OSSemCreate(1);  

    OSTaskCreate(TaskStart, (void *) 0, &TaskStartSTK[TASK_STK_SIZE - 1], 0);   // Create the first task

    OSStart();				// Start multitasking.
    /* NEVER EXECUTED */
    printf("main(): We should never execute this line\n");

    return 0;
}


/*
*********************************************************************************************************
*                                                First Task (startup ask)
*********************************************************************************************************
*/
void  TaskStart (void *pdata)
{
    INT16S     key;

    pdata = pdata;                                         /* Prevent compiler warning                 */
    INT16S i, j;
    printf("Main: initialize A matrix\n");		/*Inicializar la matriz */
    for (i=0; i<N;i++){
	    sum[i] = 0;
	    for (j=0;j<N;j++){
		    A[i][j]=i*N + j + 1;
		    printf("%4d ", A[i][j]);
	    }
	    printf("\n");
    }
    
    TaskStartCreateTasks();                                /* Create all the application tasks         */

    OSStatInit();                                          /* Initialize uC/OS-II's statistics         */

    while (count < N) {

        if (PC_GetKey(&key) == TRUE) {                     /* See if key has been pressed              */
            if (key == 0x1B) {                             /* Yes, see if it's the ESCAPE key          */
                exit(0);  	                           /* End program                              */
            }
        }

        OSTimeDlyHMSM(0, 0, 1, 0);                         /* Wait one second                          */
    }
    
    printf("Main: total = %d \n",total);
    exit(0);
}


/***********************************************************************
 * Creat Task***********************************************************
*/
static  void  TaskStartCreateTasks (void)
{
    printf("TestTask1: creat %d threads \n", N);

    INT8U  i;

    for (i = 0; i < N_TASKS; i++) {         /* Create N_TASKS identical tasks */
        TaskData[i] = '0' + i;              /* Each task will display its own letter    */
        OSTaskCreate(Task, (void *) &TaskData[i], &TaskStk[i][TASK_STK_SIZE - 1], (INT8U) (i + 1));
	printf("TestTask1: creat task %d \n", i);
    }
}

/**************************************************************************
 * **********************************************************************************
      *Task
 *
 * */

void Task (void *pdata){
    INT8U row;
    INT8U j;
    INT8U err;
    char numTarea;
    
    numTarea = *(char *)pdata;                              //Tarea
    row = numTarea - '0';
    sum[row] = 0;

    OSSemPend(SemM, 0, &err);                               //pide el semaforo
    printf("Task %c computes sum of row %d \n",numTarea, row);
    for (j=0; j<N; j++){                                //suma los numeros del renglon
        sum[row] += A[row][j]; 
    }
    OSTimeDly(1);
    OSSemPost(SemM);                                        //regresa el semaforo
    OSTimeDly(1);
    
    OSSemPend(SemTotal, 0, &err);                            //pide el semaforo
    total += sum[row];                                      //suma total
    printf("Task %c update: sum[%d] = %d, total = %d \n",numTarea, row, sum[row],total);
    count += 1;
    OSSemPost(SemTotal);                                    //regresa el semaforo

    OSTaskDel(OS_PRIO_SELF);                                //Eliminar tarea
    //OSTaskSuspend(OS_PRIO_SELF);    
}

