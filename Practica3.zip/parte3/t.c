/************ PART 2 of Programming Project ***********/

#include <stdio.h>
#include <stdlib.h>
#include "type.h"

PROC proc[NPROC], *freeList, *readyQueue, *sleepList, *running; //PROC stures 

#include "queue.c" //queue ofunctions 
#include "wait.c" //tsleep/wakeup/texit/join functions
#include "mutex.c" //mutex operattions fuctions

void tswitch();
int create(void (*f)(), void *parm);
void func(void *parm);

#define  N  4
int A[N][N]; // matrix A
MUTEX *mt; // mutex for task synchronization
int total; // global total


int init() //same as in part 1
{
    int i, j;
    PROC *p;
    for (i=0; i<NPROC; i++){
        p = &proc[i];
        p->pid = i;
        p->priority = 0;
        p->status = FREE;
        p->event = 0;
        p->joinPid = 0;
        p->joinPtr = 0;
        p->next = p+1;
    }
    proc[NPROC-1].next = 0;
    freeList = &proc[0]; // all PROCs in freeList
    readyQueue = 0;
    sleepList = 0;
    // create P0 as initial running task
    running = p = dequeue(&freeList);
    p->status = READY;
    p->priority = 0;
    printList("freeList", freeList);
    //inicializa la matriz
    printf("Po: initialize A matix\n");
    for (i=0; i<N; i++)
    {
        for (j=0; j<N; j++)
        {
            A[i][j] = i*N + j + 1;
        }
    }
    for (i=0; i<N; i++)
    { // show the matrix
        for (j=0; j<N; j++)
        {
            printf("%4d ", A[i][j]);
        }
        printf("\n");
    }

    mt = mutex_create(); // create a mutex
    total = 0;
    printf("init complete\n");
}

int myexit() // for task exit
{
texit(0);
}

void func(void *arg)
{
    int i, row, s;
    int me = running->pid;
    row = (int)arg;
    printf("task %d computes sum of row %d\n", me, row);
    s = 0;
    for (i=0; i < N; i++){
        s += A[row][i];
    }
    printf("task %d update total with %d\n", me, s);
    mutex_lock(mt);
    total += s;
    printf("[total = %d] ", total);
    mutex_unlock(mt);
}

void task1(void *parm)
{
    int pid[N];
    int i, status;
    int me = running->pid;
    printf("task %d: create working tasks : ", me);
    for(i=0; i < N; i++) {
        pid[i] = create(func, (void *)i);
        printf("%d ", pid[i]);
    }
    printf(" to compute matrix row sums\n");
    for(i=0; i<N; i++) {
        printf("task %d tries to join with task %d\n",
        running->pid, pid[i]);
        join(pid[i], &status);
    }
    printf("task %d : total = %d\n", me, total);
}


int create(void (*f)(), void *parm)
{
    int i;
    PROC *p = dequeue(&freeList);
    if (!p){
        printf("create failed\n");
        return -1;
    }
    p->status = READY;
    p->priority = 1;
    p->joinPid = 0;
    p->joinPtr = 0;
    // initialize new task stack for it to resume to f(parm)
    for (i=1; i<13; i++){ // zero out stack cells
        p->stack[SSIZE-i] = 0;}
    p->stack[SSIZE-1] = (int)parm; // function parameter
    p->stack[SSIZE-2] = (int)myexit; // function return address
    p->stack[SSIZE-3] = (int)f; // function entry
    p->ksp = (int)&p->stack[SSIZE-12]; // ksp -> stack top

    enqueue(&readyQueue, p);
//    printList("readyQueue", readyQueue);
    printf("task %d created a new task %d\n", running->pid, p->pid);
    return p->pid;
}

int main()
{
    int i, pid, status;
    printf("Welcome to the MT User-Level Threads System\n");
    init();
    create((void *)task1, 0);
    printf("P0 switch to P1\n");
    tswitch();
    printf("All tasks ended: P0 loops\n");
    while(1);
}

int scheduler()
{
    if (running->status == READY)
        enqueue(&readyQueue, running);
    running = dequeue(&readyQueue);
//    printList("readyQueue", readyQueue);
//    printf("task %d running ", running->pid);
}
