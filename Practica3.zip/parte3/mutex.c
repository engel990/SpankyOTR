/*mutex.c funciones*/

void tswitch();

typedef struct mutex{
    int lock;   //mutex lock state: 0 unlocked, 1 locked
    PROC *owner;    //pointer to owner of mutex; may also use pid
    PROC *queue;    //FIFO queue of BLOCKED waiting PROCs
}MUTEX;

MUTEX *mutex_create() // create a mutex and inicialize it
{
    MUTEX *mp = (MUTEX *)malloc(sizeof(MUTEX));
    mp->queue = 0;
    mp->lock = 0;
    mp->owner = 0;
    return mp;
}

void mutex_destroy(MUTEX *mp)
{
    free(mp);
}

int mutex_lock(MUTEX *mp)
{
    if(mp->lock == 0)
    {
        mp->lock = 1;       //locked state 
        mp->owner = running;
        printf("mutex locked\n");
    }
    else{
        enqueue(&mp->queue, running);    //runing its in mutex queue
        tswitch(); 
    }
//    printf("Aqui estoy\n");
    return -1;
}

int mutex_unlock(MUTEX *mp)
{

    if((mp->lock == 0) || (mp->lock == 1 && mp->owner != running)){
        printf("Mutex ERROR\n");
        return 0;
    }
    else if(mp->queue == 0){
//        printf("Aqui estoy unlocked\n");
        mp->lock = 0;
        mp->owner = 0;
        printf("Mutex unlocked\n");
    }
    else{
        PROC *p = dequeue(&mp->queue);
        mp->owner = p;
        enqueue(&readyQueue,p);
        printf("Task %d it's mutex owner\n",p->pid);
    }
}

