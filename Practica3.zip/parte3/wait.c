/*               Funciones wait                          */
/*tsleep    twakeup     texit   join*/

void tswitch();

/*          tsleep          */
int tsleep(int event)
{ 
//    printf("funcion sleep %d \n",event);
    running->event = event;
    running->status = SLEEP;
    running->next = 0;
    enqueue(&sleepList,running);
//    printList("sleepList", sleepList);
    tswitch();
//    printf("No hace esta linea");  /*Si la hace*/
    return event;
}

/**********************************************************/
int twakeup(int event)
{ 
    PROC *p = &proc[event];             //p apunta a la tarea que se quiere despertar
    PROC *q = sleepList;
//    printf("\n Twakeup funcion \n");
//    printList("sleepList", sleepList);
    p->status = READY;          //make p ready to run again

//  eliminarlo del sleeplist
    if (q == p)                     //if sleeplist equal to the task we want to wakeup
        sleepList = sleepList->next;
    else
    {
        while (q->next) 
        {
            if (q->next == p)
                {
                q->next = q->next->next;
                break;
                }
            q = q->next;
        }
    }

//    printf("\n Twakeup funcion \n");
    enqueue(&readyQueue, p);    //enter into ready queue
//    printf("Task %d wakeup: ",event);
//    printList("sleepList", sleepList);
//    printList("readyQueue", readyQueue);
    return event;
}

/**********************************************************/
int texit(int status)
{ 
    int b = 0;
//    printf("task %d in texit value=%d\n", running->pid, running->pid);
    PROC *p =  sleepList;
//    printList("sleepList", sleepList);
    while(p) //evalua que nadie este esperando esta tarea
    {
        if (p->joinPtr == running)
        {
//            printf("Task %d become a ZOMBIE\n", running->pid);
            running->exitStatus = status;
            running->status = ZOMBIE;
//            printf("Task %d exited with status = %d \n", running->pid, running->status);
            twakeup(p->pid);
            b = b+1;
        }
        p = p->next;
    }
//    printf("\nque pas pana \n");
    if (b != 0)
    {
        tswitch();
        return -1;
    } 

    //si nadie la esta esperando termina libremente
//    printf("task %d : no joiner=>exit as Free: ", running->pid);
    running->status = FREE;
    running->priority = 0;
//    printf("Task %d exited with status = %d \n", running->pid, running->status);
    enqueue(&freeList, running);
    tswitch();
}

/**********************************************************/
int join(int pid, int *status)
{
//    printf("task%d try to join with task%d: ",running->pid, pid);
    PROC *p = freeList;
    PROC *q = &proc[pid];
    while(p){   //evaluar si existe el pid
        //printf("libre %d \n", p->pid);
        if (p->pid == pid){
//            printf("join error: no such pid %d \n", pid);
            return 0;
            }
        p = p->next;
    }
    /*evaluar si la a tarea a la que se quiere unir, ya esta unido a la tarea actual.*/
//    if(running  ==  q -> joinPtr){
    if(running == q -> joinPtr){
//        printf("join error: DEADLOCK \n", pid);
        return 1;
    }
    /* 3  */
    running->joinPid = pid; //asignar el pid a la tarea a la que se va a unir
    running->joinPtr = q;   //se asigna el PROC al que se va a unir
    /* 4 target PID zombie proc  */
    if (q->status == ZOMBIE)
    {
//        printf("You cant because task %d it's a ZOMBIE\n",q->pid);
        *status = q->exitStatus;
        q->status = FREE;
        q->priority = 0;
        enqueue(&freeList, running);
//        printf("task %d it's not a ZOMBIE anymore and exit as FREE \n",q->pid);
        return q->pid;
    }
    /* 5 sleep()  */
    tsleep(pid);
//    printList("sleepList", sleepList);
    return pid;
}
/******** end of implementations ******/


