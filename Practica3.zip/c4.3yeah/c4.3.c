/*c4.3.c file: practica 3 de la clase SOTR
 * Solve System of Linear Equatioins by Concurrent Threads
 *
 *
 * Este codigo se escribe sobre el ejemplo #0
**************************/

#include "includes.h"

/*
*********************************************************************************************************
*                                               CONSTANTS
*********************************************************************************************************
*/
#define     N                           4		//Tamaño de la matriz
#define     TASK_STK_SIZE		512		//number of task stack (#of words)
#define     N_TASKS		        N		//numero de tasks identicos

double  A[N][N+1];
/*int A[N][N], sum[N];					//Matriz de NxN
*/
int count = 1;						//suma


/*
*********************************************************************************************************
*                                               VARIABLES
*********************************************************************************************************
*/
OS_STK  TaskStk[N_TASKS][TASK_STK_SIZE];			//Task Stack
OS_STK  WakeupTask[TASK_STK_SIZE];			//Wakeup Task
OS_STK  TaskStartSTK[TASK_STK_SIZE];
int    TaskData[N_TASKS];                      /* Parameters to pass to each task */
//OS_EVENT    *SemM;                              //Semaforo para modificar A y sum
//OS_EVENT    *SemTotal;

/*
*********************************************************************************************************
*                                           FUNCTION PROTOTYPES
*********************************************************************************************************
*/
void Task(void *arg);                                   // Thread function
void TaskStart(void *pdata);
void Wakeup(void *pdata);
static  void  TaskStartCreateTasks (void);
int kbhit();
int print_matrix();
/*
*********************************************************************************************************
*                                                MAIN
*********************************************************************************************************
*/
int main(void)
{
    // Display a banner.
#ifdef __WIN32__
    printf("##### uCOS-II V%4.2f Port V%4.2f for WIN32 #####\n", ((FP32)OSVersion())/100, ((FP32)OSPortVersion())/100);
#endif
#ifdef __LINUX__
    printf("##### uCOS-II V%4.2f Port V%4.2f for LINUX #####\n", ((FP32)OSVersion())/100, ((FP32)OSPortVersion())/100);
#endif

    OSInit();                          // Initialize uCOS-II.
/*
    SemM = OSSemCreate(1);              //crear Semaforo inicializado a 1
    SemTotal = OSSemCreate(1);  
*/
    OSTaskCreate(TaskStart, (void *) 0, &TaskStartSTK[TASK_STK_SIZE - 1], 0);   // Create the first task

    OSStart();				// Start multitasking.
    /* NEVER EXECUTED */
    printf("main(): We should never execute this line\n");

    return 0;
}


/*
*********************************************************************************************************
*                                                First Task (startup ask)
*********************************************************************************************************
*/
void  TaskStart (void *pdata)
{
    INT16S     key;
    pdata = pdata;                    /* Prevent compiler warning                 */
//    INT16S i, j;
    int i, j;
    double sum;
//    pthread_t threads[N];

    printf("main: initialize matrix A[N][N+1] as [A|B]\n");
    for (i=0; i<N; i++){
        for (j=0; j<N; j++){
            A[i][j] = 1.0;
        }
    }
    for (i=0; i<N; i++){
        A[i][N-i-1] = 1.0*N;
    }
    for (i=0; i<N; i++){
        A[i][N] = 2.0*N - 1;
    }
    print_matrix(); // show initial matrix [A|B]
//    pthread_barrier_init(&barrier, NULL, N); // set up barrier
    
    OSStatInit();                   /* Initialize uC/OS-II's statistics         */

    printf("main: create N=%d working threads\n", N);
    TaskStartCreateTasks();         /* Create all the application tasks         */

    printf("main: wait for all %d working threads to join\n", N);


    while (count < N) {

        if (PC_GetKey(&key) == TRUE) {     /* See if key has been pressed              */
            if (key == 0x1B) {            /* Yes, see if it's the ESCAPE key          */
                break;  	          /* End program                              */
            }
        }
//        printf("count: %d \n",count);
        OSTimeDlyHMSM(0, 0, 1, 0);        /* Wait one second                          */
    }
    
    printf("main: back substitution : ");
    for (i=N-1; i>=0; i--){
        sum = 0.0;
        for (j=i+1; j<N; j++){
            sum += A[i][j]*A[j][N];
        }
        A[i][N] = (A[i][N]- sum)/A[i][i];
    }
    // print solution
    printf("The solution is :\n");
    for(i=0; i<N; i++){
        printf("%6.2f ", A[i][N]);
    }
    printf("\n");
    exit(0);
}



/***********************************************************************
 * Creat Task***********************************************************
*/
static  void  TaskStartCreateTasks (void)
{
//    printf("TestTask1: creat %d threads \n", N);
    int  i;

    for (i = 0; i < N_TASKS; i++) {     /* Create N_TASKS identical tasks */
        TaskData[i] = i;                /* Each task will display its own number  */
        OSTaskCreate(Task, (void *) &TaskData[i], &TaskStk[i][TASK_STK_SIZE - 1], (int) (i + 1));
	printf("TestTask1: creat task %d \n", i);
    }

    //Wakeup Task
    OSTaskCreate(Wakeup, (void *) 0, &WakeupTask[TASK_STK_SIZE - 1], N+2);
}

/**************************************************************************
 * **********************************************************************************
      *Task
 *
 * */

void Task (void *pdata){
    
    int i, j, prow;
    int myid = *(int *)pdata;
    double temp, factor;
    for(i=0; i<N-1; i++){
        if (i == myid){
            printf("partial pivoting by thread %d on row %d: ", myid, i);
            temp = 0.0; prow = i;
            for (j=i; j<=N; j++){
                if (fabs(A[j][i]) > temp){
                    temp = fabs(A[j][i]);
                    prow = j;
                }
            }
            printf("pivot_row=%d pivot=%6.2f\n", prow, A[prow][i]);
            if (prow != i){ // swap rows
                for (j=i; j<N+1; j++){
                    temp = A[i][j];
                    A[i][j] = A[prow][j];
                    A[prow][j] = temp;
                }
            }
        }
        // wait for partial pivoting done
        // pthread_barrier_wait(&barrier);
        for(j=i+1; j<N; j++){
            if (j == myid){
                printf("thread %d do row %d\n", myid, j);
                factor = A[j][i]/A[i][i];
                for (int k=i+1; k<=N; k++)
                    A[j][k] -= A[i][k]*factor;
                A[j][i] = 0.0;
            }
        }
        // wait for current row reductions to finish
        //pthread_barrier_wait(&barrier);
        OSTaskSuspend(OS_PRIO_SELF);    
        if (i == myid){
            print_matrix();
            count++;
           // OSTaskDel(OS_PRIO_SELF);                                //Eliminar tarea
        }
    }

    OSTaskDel(OS_PRIO_SELF);                                //Eliminar tarea
   // OSTaskSuspend(OS_PRIO_SELF);    
}

/*******************************************
            Wakeup Task
*************************************************/
void Wakeup(void *pdata)
{
    int i;
    pdata = pdata;
//    printf("Wakeup Task Start \n");
    while(1)
    {   
        for(i = 0; i<N;i++){
            OSTaskResume((INT8U) (i+1));
        }

    }
    

}

/*******************************************
            Print Matrix
*************************************************/
int print_matrix()
{
    int i, j;
    printf("------------------------------------\n");
    for(i=0; i<N; i++)
    {
        for(j=0;j<N+1;j++)
                printf("%6.2f ", A[i][j]);
        printf("\n");
    }
}
