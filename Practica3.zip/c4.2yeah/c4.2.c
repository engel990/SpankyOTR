/*c4.2.c file: practica 3 de la clase SOTR
 * Compute matrix sum by threads
 *
 *
 * Este codigo se escribe sobre el ejemplo #0 haciendo referencia al ejemplo#2
**************************/

#include "includes.h"

/*
*********************************************************************************************************
*                                               CONSTANTS
*********************************************************************************************************
*/
#define     TASK_STK_SIZE		512		//number of task stack (#of words)
#define     N                           8		//Items
#define     NBUF                        4

int buf[NBUF];					        //buffer
int head = 0, tail = 0;				                //

/*
*********************************************************************************************************
*                                               VARIABLES
*********************************************************************************************************
*/
OS_STK  TaskStartSTK[TASK_STK_SIZE];
OS_STK ProducerStk[TASK_STK_SIZE];                                 // Productor
OS_STK ConsumerStk[TASK_STK_SIZE];                                 // Consumidor
//char    TaskData[N_TASKS];                      /* Parameters to pass to each task */
OS_EVENT    *full;                    //Semaforos
OS_EVENT    *empty;
OS_EVENT    *mutex;

/*
*********************************************************************************************************
*                                           FUNCTION PROTOTYPES
*********************************************************************************************************
*/
void Producer(void *arg);                                   // Productor
void Consumer(void *arg);                                   // Consumidor
void TaskStart(void *pdata);
static  void  TaskStartCreateTasks (void);
int kbhit(); 
/*
*********************************************************************************************************
*                                                MAIN
*********************************************************************************************************
*/
int main(void)
{
    // Display a banner.
#ifdef __WIN32__
    printf("##### uCOS-II V%4.2f Port V%4.2f for WIN32 #####\n", ((FP32)OSVersion())/100, ((FP32)OSPortVersion())/100);
#endif
#ifdef __LINUX__
    printf("##### uCOS-II V%4.2f Port V%4.2f for LINUX #####\n", ((FP32)OSVersion())/100, ((FP32)OSPortVersion())/100);
#endif

    OSInit();                          // Initialize uCOS-II.

    full = OSSemCreate(0);              //crear Semaforo inicializado a 1
    empty = OSSemCreate(NBUF);  
    mutex = OSSemCreate(1);  

    OSTaskCreate(TaskStart, (void *) 0, &TaskStartSTK[TASK_STK_SIZE - 1], 0);   // Create the first task

    OSStart();				// Start multitasking.
    /* NEVER EXECUTED */
    printf("main(): We should never execute this line\n");

    return 0;
}


/*
*********************************************************************************************************
*                                                First Task (startup ask)
*********************************************************************************************************
*/
void  TaskStart (void *pdata)
{
    INT16S     key;

    pdata = pdata;                                  /* Prevent compiler warning   */

   //Create Task Producer and Consumer 
    OSTaskCreate(Producer, (void *) 2, &ProducerStk[TASK_STK_SIZE], 2);  
    OSTaskCreate(Consumer, (void *) 3, &ConsumerStk[TASK_STK_SIZE], 3);  

    OSStatInit();           /* Initialize uC/OS-II's statistics */

    while (1) {

        if (PC_GetKey(&key) == TRUE) {              /* See if key has been pressed */
            if (key == 0x1B) {                      /* Yes, see if it's the ESCAPE key  */
                exit(0);  	                    /* End program       */
            }
        }

        OSTimeDlyHMSM(0, 0, 1, 0);                  /* Wait one second           */
    }
    
    printf("End \n");
    exit(0);
}

/**************************************************************************
 * ********** Producer
 * */

void Producer (void *pdata)
{
    INT16S i;
    INT8U err;
    char numTarea;

    printf("Producer start \n");
    
    for(i=0; i<N; i++)
    {
        OSSemPend(empty, 0, &err);                               //pide el semaforo
        OSSemPend(mutex, 0, &err);                               //pide el semaforo
//        OSTimeDly(1);
        buf[head++] = i+1;
        printf("producer: item %d \n", i+1);
        head %= NBUF;

        OSSemPost(mutex);     
        OSSemPost(full);     
    }
    printf("producer exit\n");
 //    OSTimeDly(1);

    OSTaskDel(OS_PRIO_SELF);                                //Eliminar tarea
    //OSTaskSuspend(OS_PRIO_SELF);    
}

/**************************************************************************
 * ********** Consumer
 * */

void Consumer (void *pdata)
{
    INT16S i, c;
    INT8U err;
    char numTarea;

    printf("Consumer start \n");
    
    for(i=0; i<N; i++)
    {
        OSSemPend(full, 0, &err);                               //pide el semaforo
        OSSemPend(mutex, 0, &err);                               //pide el semaforo

        c = buf[tail++];
        tail %= NBUF; 
        printf("consumer: got item %d \n", c);

        OSSemPost(mutex);     
        OSSemPost(empty);     
    }
    printf("consumer exit\n");
 //    OSTimeDly(1);

    OSTaskDel(OS_PRIO_SELF);                                //Eliminar tarea

}
