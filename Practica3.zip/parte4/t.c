/************ PART 4 of Programming Project ***********/

#include <stdio.h>
#include <stdlib.h>
#include "type.h"

PROC proc[NPROC], *freeList, *readyQueue, *sleepList, *running; //PROC stures 

#include "queue.c" //queue ofunctions 
#include "wait.c" //tsleep/wakeup/texit/join functions
//#include "semaphore.c" //mutex operattions fuctions

void tswitch();
int create(void (*f)(), void *parm);
void func(void *parm);

#define     NBUF    4
#define     N       8 

typedef struct
{
    int value;
    PROC *queue;
}SEMAPHORE;

int buf[NBUF], head, tail; // buffers for producer-consumer
SEMAPHORE full, empty, mutex; // semaphores

int P(SEMAPHORE *s) // implement P function 
{
    --s->value;
//    printList("readyQueue", readyQueue);
//    printf("P semophore %d\n", s->value);
    if(s->value < 0)//bloquear el semaforo y esperar
    {
//        printf("P semophore %d\n", s->value);
        enqueue(&s->queue, running);
//        printList("Queue", s->queue);        
            s->value = 0;
//    printList("readyQueue", readyQueue);
        tswitch();
    }
}

int V(SEMAPHORE *s) // implement V function 
{
    ++s->value;
//    SEMAPHORE *ss = s;
//    printf("V semophore %d\n", s->value);
     if(s->value <= 0 )
    {
        PROC *p = dequeue(&s->queue);
//        printList("Queue", s->queue); 
//    printList("readyQueue", readyQueue);
        enqueue(&readyQueue,p);
         
    }
}

void producer() // produce task code
{
    int i;
    printf("producer %d start\n", running->pid);
    for (i=0; i<N; i++){
//printList("readyQueue", readyQueue);
        P(&empty);
        P(&mutex);
        buf[head++] = i+1;
        printf("producer %d: item = %d\n", running->pid, i+1);
        head %= NBUF;
        V(&mutex);
        V(&full);
    }
    printf("producer %d exit\n", running->pid);
    }

void consumer() // consumer task code
{
    int i, c;
    printf("consumer %d start\n", running->pid);
    for (i=0; i<N; i++) {
//printList("readyQueue", readyQueue);
        P(&full);
        P(&mutex);
        c = buf[tail++];
        tail %= NBUF;
        printf("consumer %d: got item = %d\n", running->pid, c);
        V(&mutex);
        V(&empty);
    }
    printf("consumer %d exit\n", running->pid);
}


int init() //same as in part 1
{
    int i, j;
    PROC *p;
    for (i=0; i<NPROC; i++){
        p = &proc[i];
        p->ppid = 1;
        p->pid = i;
        p->priority = 0;
        p->status = FREE;
        p->event = 0;
        p->joinPid = 0;
        p->joinPtr = 0;
        p->next = p+1;
    }
    proc[NPROC-1].next = 0;
    freeList = &proc[0]; // all PROCs in freeList
    readyQueue = 0;
    sleepList = 0;
    // create P0 as initial running task
    running = p = dequeue(&freeList);
    p->status = READY;
    p->priority = 0;
    printList("freeList", freeList);
    // initialize semaphores full, empty, mutex
    head = tail = 0;
    full.value = 0;     full.queue = 0;
    empty.value=NBUF;   empty.queue = 0;
    mutex.value = 1;    mutex.queue = 0;    
    printf("init complete\n");
    
}

int myexit() // for task exit
{
texit(0);
}

int task1()
{
    int status;
    printf("task %d creates producer-consumer tasks\n", running->pid);
    create((void *)producer, 0);
    create((void *)consumer, 0);
printList("readyQueue", readyQueue);
    join(2, &status);
    join(3, &status);
    printf("task %d exit\n", running->pid);
}


int create(void (*f)(), void *parm)
{
    int i;
    PROC *p = dequeue(&freeList);
    if (!p){
        printf("create failed\n");
        return -1;
    }
    p->ppid = running->pid;
    p->status = READY;
    p->priority = 1;
    p->joinPid = 0;
    p->joinPtr = 0;
    // initialize new task stack for it to resume to f(parm)
    for (i=1; i<13; i++){ // zero out stack cells
        p->stack[SSIZE-i] = 0;}
    p->stack[SSIZE-1] = (int)parm; // function parameter
    p->stack[SSIZE-2] = (int)myexit; // function return address
    p->stack[SSIZE-3] = (int)f; // function entry
    p->ksp = (int)&p->stack[SSIZE-12]; // ksp -> stack top

    enqueue(&readyQueue, p);
    printf("task %d created a new task %d\n", running->pid, p->pid);
    return p->pid;
}

int main()
{
    int i, pid, status;
    printf("Welcome to the MT User-Level Threads System\n");
    init();
    create((void *)task1, 0);
    printf("P0 switch to P1\n");

    tswitch();
    printf("All tasks ended: P0 loops\n");
    while(1);
}

int scheduler()
{
    if (running->status == READY)
        enqueue(&readyQueue, running);
    running = dequeue(&readyQueue);
}
