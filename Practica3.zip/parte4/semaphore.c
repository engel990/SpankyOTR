/*Funciones del semaforo*/

void tswitch();

typedef struct
{
    int value;
    PROC *queue;
}SEMAPHORE;

int P(SEMAPHORE *s) // implement P function 
{
    s->value--;
    if(s->value < 0)//bloquear el semaforo y esperar
    {
        enqueue(&s->queue, running);
        tswitch();
    }
}

int V(SEMAPHORE *s) // implement V function 
{
    s->value++;
    if(s->value <= 0 )
    {
        PROC *p = dequeue(&s->queue);
        enqueue(&readyQueue,p);
        
    }
}

