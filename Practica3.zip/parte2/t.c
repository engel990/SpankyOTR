/************ PART 2 of Programming Project ***********/

#include <stdio.h>
#include <stdlib.h>
#include "type.h"

PROC proc[NPROC]; // NPROC proc structures
PROC *freeList; // free PROC list
PROC *readyQueue; // ready proc priority queue
PROC *sleepList; // sleep PROC list
PROC *running; // running proc pointer

#include "queue.c" // enqueue(), dequeue(), printList()
void tswitch();
int create(void (*f)(), void *parm);
void func(void *parm);


/****** implement these functions ******/
int tsleep(int event)
{ 
//    printf("funcion sleep %d \n",event);
    running->event = event;
    running->status = SLEEP;
    running->next = 0;
    enqueue(&sleepList,running);
    printList("sleepList", sleepList);
    tswitch();
//    printf("No hace esta linea");  /*Si la hace*/
    return event;
}

int twakeup(int event)
{ 
    PROC *p = &proc[event];             //p apunta a la tarea que se quiere despertar
    PROC *q = sleepList;
//    PROC *qq;
//    printf("\n Twakeup funcion \n");
    printList("sleepList", sleepList);
    p->status = READY;          //make p ready to run again

//  eliminarlo del sleeplist
    if (q == p)                     //if sleeplist equal to the task we want to wakeup
        sleepList = sleepList->next;
    else
    {
        while (q->next) 
        {
            if (q->next == p)
                {
                q->next = q->next->next;
                break;
                }
            q = q->next;
        }
    }

//    printf("\n Twakeup funcion \n");
    enqueue(&readyQueue, p);    //enter into ready queue
    printf("Task %d wakeup: ",event);
    printList("sleepList", sleepList);
//    printList("readyQueue", readyQueue);
    return event;
}

int texit(int status)
{ 
    int b = 0;
    printf("task %d in texit value=%d\n", running->pid, running->pid);
    PROC *p =  sleepList;
    printList("sleepList", sleepList);
    while(p) //evalua que nadie este esperando esta tarea
    {
        if (p->joinPtr == running)
        {
            printf("Task %d become a ZOMBIE\n", running->pid);
            running->exitStatus = status;
            running->status = ZOMBIE;
            printf("Task %d exited with status = %d \n", running->pid, running->status);
            twakeup(p->pid);
            b = b+1;
        }
        p = p->next;
    }
//    printf("\nque pas pana \n");
    if (b != 0)
    {
        tswitch();
        return -1;
    } 

    //si nadie la esta esperando termina libremente
    printf("task %d : no joiner=>exit as Free: ", running->pid);
    running->status = FREE;
    running->priority = 0;
    printf("Task %d exited with status = %d \n", running->pid, running->status);
//    printList("readyQueue", readyQueue);
    enqueue(&freeList, running);
//    printList("readyQueue", readyQueue);
//    printList("freeList", freeList);
    tswitch();
}

int join(int pid, int *status)
{
//    printf("\n \n funcion join %d \n",freeList->pid);
    printf("task%d try to join with task%d: ",
        running->pid, pid);
    PROC *p = freeList;
    PROC *q = &proc[pid];
//    printf("pid: %d next: %d \n",q->pid, q->next);
    while(p){   //evaluar si existe el pid
        //printf("libre %d \n", p->pid);
        if (p->pid == pid){
            printf("join error: no such pid %d \n", pid);
            return -1;
            }
        p = p->next;
    }
    /*evaluar si la a tarea a la que se quiere unir, ya esta unido a la tarea actual.*/
//    if(running  ==  q -> joinPtr){
    if(running == q -> joinPtr){
        printf("join error: DEADLOCK \n", pid);
        return -1;
    }
    /* 3  */
    running->joinPid = pid; //asignar el pid a la tarea a la que se va a unir
    running->joinPtr = q;   //se asigna el PROC al que se va a unir
    /* 4 target PID zombie proc  */
    if (q->status == ZOMBIE)
    {
        printf("You cant because task %d it's a ZOMBIE\n",q->pid);
        *status = q->exitStatus;
        q->status = FREE;
        q->priority = 0;
        enqueue(&freeList, running);
        printf("task %d it's not a ZOMBIE anymore and exit as FREE \n",q->pid);
        return q->pid;
    }
    /* 5 sleep()  */
    tsleep(pid);
//    printList("sleepList", sleepList);
    return pid;
}
/******** end of implementations ******/


int init() //same as in part 1
{
    int i, j;
    PROC *p;
    for (i=0; i<NPROC; i++){
        p = &proc[i];
        p->pid = i;
        p->priority = 0;
        p->status = FREE;
        p->event = 0;
        p->joinPid = 0;
        p->joinPtr = 0;
        p->next = p+1;
    }
    proc[NPROC-1].next = 0;
    freeList = &proc[0]; // all PROCs in freeList
    readyQueue = 0;
    sleepList = 0;
    // create P0 as initial running task
    running = p = dequeue(&freeList);
    p->status = READY;
    p->priority = 0;
    printList("freeList", freeList);
    printf("init complete: P0 running\n");
}

int do_create()
{
    int pid = create(func, (void*)(running->pid)); // parm = pid
    return pid;
}

int do_switch()
{
    tswitch();
}

int do_exit()
{
    texit(running->pid); // for simplicity: exit with pid value
}

int do_join()
{
    int status;
    int c;
    printf("entern a pid to join with : ");
    c = getchar();getchar();
    c = c - '0';
//    scanf("%d",&c);// getchar(); //kill
//    printf("lo que lee: %d ",c);
    join(c,&status);
}

void task1(void *parm) // task1: demonstrate create-join operations
{
    int pid[2];
    int i, status;
    //printf("task %d create subtasks\n", running->pid);
    printf("\n");
    for (i=0; i<2; i++){ // P1 creates P2, P3
        pid[i] = create(func, (void *)running->pid);
    }
    join(5, &status); // try to join with targetPid=5
    for (i=0; i<2; i++){ // try to join with P2, P3
        pid[i] = join(pid[i], &status);
//        printf("task%d joined with task%d: status = %d\n",
//            running->pid, pid[i], status);
    }
}

void func(void *parm)
{
    char c;
//    printf("task %d start: parm = %d\n", running->pid, parm);
    while(1){
        printList("readyQueue", readyQueue);
//        printList("sleepList", sleepList);
//        printList("freeList", freeList);
        printf("task %d running ", running->pid);
        printf("enter a key [c|s|q|j] : ");
        c = getchar(); getchar(); //kill
//        scanf("%c",&c);
        switch (c){
            case 'c' : do_create(); break;
            case 's' : do_switch(); break;
            case 'q' : do_exit(); break;
            case 'j' : do_join(); break;
        }
    }
}

int create(void (*f)(), void *parm)
{
    int i;
    PROC *p = dequeue(&freeList);
    if (!p){
        printf("create failed\n");
        return -1;
    }
    p->status = READY;
    p->priority = 1;
    p->joinPid = 0;
    p->joinPtr = 0;
    // initialize new task stack for it to resume to f(parm)
    for (i=1; i<13; i++){ // zero out stack cells
        p->stack[SSIZE-i] = 0;}
    p->stack[SSIZE-1] = (int)parm; // function parameter
    p->stack[SSIZE-2] = (int)do_exit; // function return address
    p->stack[SSIZE-3] = (int)f; // function entry
    p->ksp = (int)&p->stack[SSIZE-12]; // ksp -> stack top

    enqueue(&readyQueue, p);
//    printList("readyQueue", readyQueue);
    printf("task %d created a new task %d\n", running->pid, p->pid);
    return p->pid;
}

int main()
{
    int i, pid, status;
    printf("Welcome to the MT User-Level Threads System\n");
    init();
    create((void *)task1, 0);
    printf("P0 switch to P1\n");
    tswitch();
    printf("All tasks ended: P0 loops\n");
    while(1);
}

int scheduler()
{
    if (running->status == READY)
        enqueue(&readyQueue, running);
    running = dequeue(&readyQueue);
//    printList("readyQueue", readyQueue);
//    printf("task %d running ", running->pid);
}
