/***************** queue.c file *****************/
int enqueue(PROC **queue, PROC *p)
{
    PROC *q = *queue;
    if (q == 0 || p->priority > q->priority){
    *queue = p;
    p->next = q;
    }
    else{
        while (q->next && p->priority <= q->next->priority)
            q = q->next;
        p->next = q->next;
        q->next = p;
    }
}
PROC *dequeue(PROC **queue)
{
    PROC *p = *queue;
    if (p)
        *queue = (*queue)->next;
    return p;
}
int printList(char *name, PROC *p)
{
    printf("%s = ", name);
    while(p){
        printf("%d --> ", p->pid);
        p = p->next;
    }
    printf("NULL\n");
}

/*Revisalro no furula, debe ser igual al usado en wakeup()*/
int supqueue(PROC **queue, PROC *p)//funcion para eliminar de la lista 
{
    PROC *q = *queue;
    if(q == p){
//        enqueue();
        *queue = (*queue)->next;}
    else{
        while (q->next){
            if(q->next == p)
            {
                q->next = p->next;
            }
            q = q->next;
        }
    }
}
